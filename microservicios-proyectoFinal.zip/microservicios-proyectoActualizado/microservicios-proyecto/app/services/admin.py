import inspect
import math
import datetime
from typing import Dict, Any, List, Tuple

from fastapi import APIRouter, HTTPException, FastAPI, Query, Request
from pydantic import BaseModel

router = APIRouter(prefix="/admin", tags=["Administrador de microservicios"])

# Registro en memoria de microservicios
microservicios: Dict[str, Dict[str, Any]] = {}
app_ref: FastAPI = None  # será asignado desde main.py al arrancar


class Microservicio(BaseModel):
    nombre: str
    descripcion: str
    codigo: str


@router.on_event("startup")
def startup_event():
    print("Administrador de microservicios cargado")


def registrar_microservicio(nombre: str, codigo: str) -> Dict[str, Any]:
    """
    Ejecuta el código recibido (que debe definir `funcion`) y registra
    un endpoint dinámico en la app FastAPI (app_ref).
    """
    global app_ref

    print(f" Registrando microservicio: {nombre}")
    print(f" app_ref está activa: {app_ref is not None}")

    # Entorno limitado / utilidades disponibles para el código dinámico
    entorno_seguro = {
        "Query": Query,
        "math": math,
        "datetime": datetime,
    }
    local_vars: Dict[str, Any] = {}

    # Ejecutar el código enviado por el admin (ATENCIÓN: security risk)
    try:
        exec(codigo, entorno_seguro, local_vars)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Error ejecutando el código: {e}")

    # Verificar que exista la función "funcion"
    if "funcion" not in local_vars or not callable(local_vars["funcion"]):
        raise HTTPException(status_code=400, detail="El código debe definir una función llamada 'funcion'")

    funcion = local_vars["funcion"]
    endpoint = f"/{nombre}"

    # Inspect signature
    sig = inspect.signature(funcion)
    params_items: List[Tuple[str, inspect.Parameter]] = list(sig.parameters.items())
    param_names: List[str] = [name for name, _ in params_items]

    # wrapper async que acepta Request, parsea query params y llama a la función original
    async def wrapper(request: Request):
        raw_qs = dict(request.query_params)  # dict de strings
        kwargs: Dict[str, Any] = {}

        # parsear y validar parámetros según annotations/defaults
        for pname, pparam in params_items:
            if pname in raw_qs:
                raw_val = raw_qs[pname]
                annot = pparam.annotation

                try:
                    if annot is inspect._empty or annot == str:
                        val = raw_val
                    elif annot == int:
                        val = int(raw_val)
                    elif annot == float:
                        val = float(raw_val)
                    elif annot == bool:
                        val = raw_val.lower() in ("1", "true", "yes", "y")
                    else:
                        # intento genérico de conversión con el tipo anotado
                        try:
                            val = annot(raw_val)
                        except Exception:
                            val = raw_val
                except Exception as e:
                    raise HTTPException(status_code=400, detail=f"Error parseando parámetro '{pname}': {e}")

                kwargs[pname] = val
            else:
                # no llegó el parámetro: si no tiene default => error
                if pparam.default is inspect._empty:
                    raise HTTPException(status_code=400, detail=f"Falta parámetro requerido: {pname}")
                # si tiene default, se deja asi

        # Llamar a la función original
        try:
            if inspect.iscoroutinefunction(funcion):
                result = await funcion(**kwargs)
            else:
                result = funcion(**kwargs)
            return result
        except HTTPException:
            raise
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error en ejecución del microservicio: {e}")

    
    try:
        # eliminar ruta existente con mismo path (si existe)
        existing = [r for r in app_ref.router.routes if hasattr(r, "path") and r.path == endpoint]
        if existing:
            app_ref.router.routes = [r for r in app_ref.router.routes if not (hasattr(r, "path") and r.path == endpoint)]

        app_ref.add_api_route(
            path=endpoint,
            endpoint=wrapper,
            methods=["GET"],
            name=nombre,
            summary=f"Microservicio dinámico: {nombre}",
            response_model=None,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error registrando la ruta: {e}")

    # Guardar metadata
    microservicios[nombre] = {
        "descripcion": "Creado desde la interfaz web",
        "ruta": endpoint,
        "parametros": param_names,
    }

    print(f" Ruta registrada correctamente: {endpoint}")
    print(f" Parámetros detectados: {param_names}")
    return {"ruta": endpoint, "parametros": param_names}


@router.post("/crear")
def crear_microservicio(data: Microservicio):
    """Crea y registra un microservicio dinámico"""
    if data.nombre in microservicios:
        raise HTTPException(status_code=400, detail="Ya existe un microservicio con ese nombre")

    info = registrar_microservicio(data.nombre, data.codigo)
    microservicios[data.nombre] = {
        "descripcion": data.descripcion,
        "ruta": info["ruta"],
        "parametros": info["parametros"],
    }
    return {"mensaje": "Microservicio creado", **info}


@router.get("/")
def listar_microservicios():
    """Lista todos los microservicios activos junto con sus parámetros"""
    return microservicios


@router.delete("/eliminar/{nombre}")
def eliminar_microservicio(nombre: str):
    """Elimina un microservicio dinámico del registro y del router"""
    if nombre not in microservicios:
        raise HTTPException(status_code=404, detail="Microservicio no encontrado")

    del microservicios[nombre]

    global app_ref
    if app_ref:
        app_ref.router.routes = [
            r for r in app_ref.router.routes
            if not (hasattr(r, "path") and r.path == f"/{nombre}")
        ]

    print(f" Microservicio eliminado: {nombre}")
    return {"mensaje": f"Microservicio '{nombre}' eliminado correctamente"}
