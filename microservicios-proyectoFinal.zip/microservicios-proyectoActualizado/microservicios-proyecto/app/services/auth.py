from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel
import secrets

router = APIRouter(prefix="/auth", tags=["Autenticación"])

# Almacenamiento temporal de sesiones (en memoria)
usuarios = {"admin": "1234"}  # Usuario de prueba
tokens = {}

class Credenciales(BaseModel):
    usuario: str
    contrasena: str


@router.post("/login")
def login(data: Credenciales):
    if data.usuario not in usuarios or usuarios[data.usuario] != data.contrasena:
        raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")

    token = secrets.token_hex(16)
    tokens[token] = data.usuario
    return {"token": token, "usuario": data.usuario}


@router.post("/logout")
def logout(authorization: str = Header(None)):
    token = authorization.replace("Bearer ", "") if authorization else None
    if token in tokens:
        del tokens[token]
        return {"mensaje": "Sesión cerrada"}
    raise HTTPException(status_code=401, detail="Token inválido o expirado")


def verificar_token(authorization: str = Header(None)):
    """Función auxiliar para validar token en los endpoints protegidos"""
    token = authorization.replace("Bearer ", "") if authorization else None
    if token not in tokens:
        raise HTTPException(status_code=401, detail="No autorizado")
    return tokens[token]
