from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from app.services import admin, auth

# Crear instancia principal de FastAPI
app = FastAPI(title="Plataforma de Microservicios con Login", version="1.1.0")

# Importante: enlazar la referencia global del admin con la app principal
admin.app_ref = app

#======================== Modificado - v1#
app.include_router(auth.router)
app.include_router(admin.router)

# Middleware CORS (para permitir frontend)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permite el acceso desde cualquier dominio (puedes restringirlo luego)
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Montar routers
app.include_router(auth.router)
app.include_router(admin.router)

# Montar la carpeta 'static' para servir el index.html
app.mount("/web", StaticFiles(directory="app/static", html=True), name="web")

# Ruta raíz (prueba simple de que la app funciona)
@app.get("/")
def root():
    return {"mensaje": "Hola mundo, FastAPI está funcionando 🚀"}
