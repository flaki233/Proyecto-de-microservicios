# Plataforma de Microservicios con Autenticación Roble

Este proyecto es una plataforma web para gestionar, ejecutar y probar microservicios dinámicos, con autenticación integrada mediante el servicio Roble.  
Permite a cualquier usuario crear sus propios microservicios, definir parámetros, ejecutarlos desde una interfaz sencilla y conectarse usando su propia base de datos de Roble.

## Descripción general

El sistema está compuesto por dos partes: un frontend en HTML, CSS y JavaScript, y un backend desarrollado con FastAPI.  
El frontend permite a los usuarios autenticarse, crear microservicios y ejecutarlos directamente desde la web.  
El backend se encarga de almacenar, procesar y exponer las rutas dinámicas correspondientes a cada microservicio creado.


### Autenticación con Roble
- Compatible con cualquier instancia de Roble (`https://roble-api.openlab.uninorte.edu.co/auth/:dbName`).
- Los usuarios pueden iniciar sesión utilizando su correo y contraseña registrados en su propia base.
- El sistema valida automáticamente el token de acceso mediante el endpoint `/verify-token`.

### Gestión de microservicios
- Permite crear nuevos microservicios directamente desde la interfaz web.
- Cada microservicio se almacena con un nombre, descripción y el código fuente de una función Python.
- Se puede consultar un listado con todos los microservicios disponibles.
- Admite ejecución directa desde la interfaz, incluyendo parámetros personalizados.
- Posibilidad de eliminar microservicios creados.

### Interfaz de usuario
- Construida con HTML, CSS y JavaScript puro.
- Diseño simple, enfocado en la usabilidad.
- Muestra claramente los resultados o errores de ejecución.
- Acceso al panel de administración restringido a usuarios autenticados.


## Requisitos previos

Antes de ejecutar el proyecto, asegúrate de tener instalado lo siguiente:

- **Python 3.10 o superior**
- **pip** (gestor de paquetes de Python)
- **Docker y Docker Compose** (si vas a usar la versión con contenedores)
- **FastAPI** y **Uvicorn** (se instalan con `requirements.txt`)


### Backend (API)
El backend debe ejecutarse en:
```
http://localhost:8000
```

Endpoints disponibles:
- `/auth/login` → autenticación local (si se usa)
- `/admin/crear` → crear microservicio
- `/admin/` → listar microservicios
- `/admin/eliminar/:nombre` → eliminar microservicio
- `/:nombre` → ejecutar un microservicio existente

### Frontend
Para iniciar la aplicación, basta con abrir el archivo index.html en un navegador web.  
No requiere instalación ni dependencias adicionales.

## Tecnologías utilizadas

- Frontend: HTML5, CSS3, JavaScript (Fetch API)
- Backend: FastAPI (Python)
- Autenticación: Roble API (JWT y Refresh Tokens)
- Estilos: CSS puro, diseño minimalista y adaptable

## Ejecución local

Instalar dependencias e iniciar el servidor localmente:
```bash
pip install -r requirements.txt
```

Construir y ejecutar con Docker:

docker compose up 

Bajar de docker

docker compose down
```

Verificar la documentación interactiva de FastAPI:
```
http://127.0.0.1:8000/docs
```

Abrir la página principal:
```
http://127.0.0.1:8000/web/
```

### Ejemplos de microservicios


Tener en cuenta que al agregar el nombre del microservicio no deben haber espacio entre las palabras, usar "_" como alternativa

**hola_mundo**
```python
def funcion():
    return {"mensaje": "¡Hola mundo!"}
```

**sumadora**
```python
def funcion(a: float, b: float):
    print("Recibidos:", a, b)
    return {"resultado": a + b}
```

## Diagrama de Arquitectura

A continuación se muestra una vista general de la arquitectura del sistema y cómo interactúan sus componentes principales:

```
┌──────────────────────────────────────────────────────────┐
│                    Usuario / Navegador                   │
│                                                          │
│  ┌────────────────────────────────────────────────────┐  │
│  │ Interfaz Web (index.html + JavaScript)             │  │
│  │                                                    │  │
│  │ - Permite al usuario iniciar sesión usando Roble   │  │
│  │ - Envía peticiones HTTP al backend (FastAPI)       │  │
│  │ - Muestra resultados y gestión de microservicios   │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
                           │
                           │  (HTTP / JSON)
                           ▼
┌──────────────────────────────────────────────────────────┐
│                    Backend FastAPI                       │
│                                                          │
│  ┌────────────────────────────────────────────────────┐  │
│  │ Módulo /auth                                       │  │
│  │ - Envía credenciales a Roble                       │  │
│  │ - Recibe y valida accessTokens                     │  │
│  │ - Controla acceso a rutas protegidas               │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌────────────────────────────────────────────────────┐  │
│  │ Módulo /admin                                      │  │
│  │ - Crea, ejecuta y elimina microservicios dinámicos │  │
│  │ - Expone endpoints REST para la interfaz web       │  │
│  └────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────┘
                           │
                           │  (API externa HTTPS)
                           ▼
┌──────────────────────────────────────────────────────────┐
│                     Roble API (Auth)                     │
│                                                          │
│ - Servicio externo de autenticación                      │
│ - Devuelve accessToken y refreshToken                    │
│ - Endpoints: /login, /signup, /verify-token, etc.        │
│ - Cada proyecto usa su propia base de datos (dbName)     │
└──────────────────────────────────────────────────────────┘
```

Este esquema refleja cómo el usuario se autentica mediante Roble, accede a tu backend FastAPI y gestiona los microservicios a través de la interfaz web.


## Licencia

Este proyecto es de código abierto y puede utilizarse libremente con fines educativos o experimentales.  
Autor: *Juan campo, Alinson pajaro, Andres Gomes, Andrea de la Ossa*  
Universidad del Norte – OpenLab Roble
